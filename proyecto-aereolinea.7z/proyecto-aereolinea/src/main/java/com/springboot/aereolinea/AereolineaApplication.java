package com.springboot.aereolinea;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AereolineaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AereolineaApplication.class, args);
	}

}
