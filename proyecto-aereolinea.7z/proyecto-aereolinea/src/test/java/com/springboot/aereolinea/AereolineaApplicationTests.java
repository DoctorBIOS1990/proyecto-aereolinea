package com.springboot.aereolinea;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AereolineaApplicationTests {

	@Test
	void contextLoads() {
	}

}
